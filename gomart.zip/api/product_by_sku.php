<?php
require_once '../config.php';
header('Content-Type: application/json');
requireLogin();

$sku = sanitize($_GET['sku'] ?? '');
if (!$sku) { echo json_encode(['error' => 'No SKU']); exit; }

$db = getDB();
$res = mysqli_query($db, "SELECT p.*, c.nama as cat_name FROM products p JOIN categories c ON p.category_id = c.id WHERE p.sku = '$sku' LIMIT 1");
$prod = mysqli_fetch_assoc($res);
if ($prod) {
    echo json_encode($prod);
} else {
    echo json_encode(['error' => 'Not found']);
}
