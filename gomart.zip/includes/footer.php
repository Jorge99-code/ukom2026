    </main>
</div>
<div class="sidebar-overlay" id="sidebarOverlay" onclick="toggleMobileSidebar()"></div>
<script src="<?= BASE_URL ?>/js/main.js"></script>
<?php if (isset($extraJs)): ?>
<script src="<?= BASE_URL ?>/js/<?= $extraJs ?>"></script>
<?php endif; ?>
</body>
</html>
