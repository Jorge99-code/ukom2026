<?php
requireLogin();
$cashier = getCurrentCashier();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($pageTitle) ? e($pageTitle) . ' - ' : '' ?><?= STORE_NAME ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= BASE_URL ?>/css/style.css">
</head>
<body>
<div class="app-layout">
    <!-- Sidebar -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo">
                <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <rect width="32" height="32" rx="8" fill="#FF0000"/>
                    <path d="M6 12h20M6 12l2-4h16l2 4M6 12v12h20V12" stroke="white" stroke-width="1.8" stroke-linejoin="round"/>
                    <path d="M12 18h8M12 22h5" stroke="white" stroke-width="1.8" stroke-linecap="round"/>
                    <circle cx="10" cy="27" r="2" fill="white"/>
                    <circle cx="22" cy="27" r="2" fill="white"/>
                </svg>
                <span class="logo-text"><?= STORE_NAME ?></span>
            </div>
            <button class="sidebar-toggle-btn" id="sidebarToggle">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
            </button>
        </div>
        <nav class="sidebar-nav">
            <a href="<?= BASE_URL ?>/index.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) === 'index.php' && strpos($_SERVER['PHP_SELF'], 'pages') === false ? 'active' : '' ?>">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
                <span>Kasir</span>
            </a>
            <a href="<?= BASE_URL ?>/pages/transactions/index.php" class="nav-item <?= strpos($_SERVER['PHP_SELF'], 'transactions') !== false ? 'active' : '' ?>">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>
                <span>Transaksi</span>
            </a>
            <?php if ($cashier['role'] === 'admin'): ?>
            <a href="<?= BASE_URL ?>/pages/products/index.php" class="nav-item <?= strpos($_SERVER['PHP_SELF'], 'products') !== false ? 'active' : '' ?>">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg>
                <span>Produk</span>
            </a>
            <a href="<?= BASE_URL ?>/pages/categories/index.php" class="nav-item <?= strpos($_SERVER['PHP_SELF'], 'categories') !== false ? 'active' : '' ?>">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
                <span>Kategori</span>
            </a>
            <a href="<?= BASE_URL ?>/pages/cashiers/index.php" class="nav-item <?= strpos($_SERVER['PHP_SELF'], 'cashiers') !== false ? 'active' : '' ?>">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                <span>Kasir</span>
            </a>
            <?php endif; ?>
        </nav>
        <div class="sidebar-footer">
            <a href="<?= BASE_URL ?>/pages/cashiers/profile.php?id=<?= $cashier['id'] ?>" class="profile-link">
                <div class="avatar"><?= strtoupper(substr($cashier['username'], 0, 1)) ?></div>
                <div class="profile-info">
                    <div class="profile-name"><?= e($cashier['username']) ?></div>
                    <div class="profile-role"><?= e($cashier['role']) ?></div>
                </div>
            </a>
            <a href="<?= BASE_URL ?>/pages/auth/logout.php" class="logout-btn" title="Logout">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
            </a>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="main-content" id="mainContent">
        <div class="topbar">
            <div class="topbar-left" style="display:flex;align-items:center;gap:8px">
                <button class="topbar-hamburger" id="mobileMenuBtn" onclick="toggleMobileSidebar()">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
                </button>
                <h1 class="page-title"><?= isset($pageTitle) ? e($pageTitle) : '' ?></h1>
            </div>
            <div class="topbar-right">
                <div class="store-badge">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                    <?= STORE_LOCATION ?>
                </div>
            </div>
        </div>
        <?php if (isset($_GET['success'])): ?>
        <div class="alert alert-success"><?= e($_GET['success']) ?></div>
        <?php endif; ?>
        <?php if (isset($_GET['error'])): ?>
        <div class="alert alert-error"><?= e($_GET['error']) ?></div>
        <?php endif; ?>
