<?php
require_once '../../config.php';
requireAdmin();
$pageTitle = 'Manajemen Kasir';

$db = getDB();

// Handle delete
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    if ($id == $_SESSION['cashier_id']) {
        header('Location: ' . BASE_URL . '/pages/cashiers/index.php?error=Tidak bisa menghapus akun sendiri');
        exit;
    }
    mysqli_query($db, "DELETE FROM cashiers WHERE id = $id");
    header('Location: ' . BASE_URL . '/pages/cashiers/index.php?success=Kasir berhasil dihapus');
    exit;
}

// Handle role change
if (isset($_GET['role']) && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $role = sanitize($_GET['role']);
    if (in_array($role, ['admin', 'cashier']) && $id != $_SESSION['cashier_id']) {
        mysqli_query($db, "UPDATE cashiers SET role='$role' WHERE id=$id");
    }
    header('Location: ' . BASE_URL . '/pages/cashiers/index.php?success=Role berhasil diubah');
    exit;
}

$cashiers = [];
$res = mysqli_query($db, "SELECT c.*, (SELECT COUNT(*) FROM transactions t WHERE t.cashier_id = c.id) as trx_count FROM cashiers c ORDER BY c.created_at DESC");
while ($row = mysqli_fetch_assoc($res)) $cashiers[] = $row;

include '../../includes/header.php';
?>
<div class="content">
<div class="card">
    <div class="card-header">
        <span class="card-title">Daftar Kasir (<?= count($cashiers) ?>)</span>
    </div>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Transaksi</th>
                    <th>Bergabung</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($cashiers as $i => $c): ?>
                <tr>
                    <td class="text-muted"><?= $i+1 ?></td>
                    <td>
                        <div class="d-flex align-center gap-8">
                            <div class="avatar" style="width:28px;height:28px;font-size:11px"><?= strtoupper(substr($c['username'],0,1)) ?></div>
                            <span class="fw-700"><?= e($c['username']) ?></span>
                            <?php if ($c['id'] == $_SESSION['cashier_id']): ?>
                            <span class="badge badge-green">Kamu</span>
                            <?php endif; ?>
                        </div>
                    </td>
                    <td class="text-muted"><?= e($c['email']) ?></td>
                    <td>
                        <span class="badge <?= $c['role'] === 'admin' ? 'badge-red' : 'badge-blue' ?>">
                            <?= e($c['role']) ?>
                        </span>
                    </td>
                    <td><?= $c['trx_count'] ?></td>
                    <td class="text-muted"><?= date('d/m/Y', strtotime($c['created_at'])) ?></td>
                    <td>
                        <div class="btn-group">
                            <a href="<?= BASE_URL ?>/pages/cashiers/profile.php?id=<?= $c['id'] ?>" class="btn btn-secondary btn-sm">Profil</a>
                            <?php if ($c['id'] != $_SESSION['cashier_id']): ?>
                            <?php if ($c['role'] === 'cashier'): ?>
                            <a href="?role=admin&id=<?= $c['id'] ?>" class="btn btn-outline btn-sm" onclick="return confirm('Jadikan admin?')">→ Admin</a>
                            <?php else: ?>
                            <a href="?role=cashier&id=<?= $c['id'] ?>" class="btn btn-secondary btn-sm" onclick="return confirm('Turunkan ke kasir?')">→ Kasir</a>
                            <?php endif; ?>
                            <button class="btn btn-danger btn-sm" onclick="confirmDelete('<?= BASE_URL ?>/pages/cashiers/index.php?delete=<?= $c['id'] ?>', 'Hapus kasir <?= e(addslashes($c['username'])) ?>?')">Hapus</button>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
</div>
<?php include '../../includes/footer.php'; ?>
