<?php
require_once '../../config.php';
requireLogin();
$pageTitle = 'Profil Kasir';

$db = getDB();
// Anyone can view any profile, but cashier can only edit themselves
$targetId = isset($_GET['id']) ? intval($_GET['id']) : $_SESSION['cashier_id'];
if (!$targetId) $targetId = $_SESSION['cashier_id'];

$cashier = mysqli_fetch_assoc(mysqli_query($db, "SELECT * FROM cashiers WHERE id = $targetId LIMIT 1"));
if (!$cashier) { header('Location: ' . BASE_URL . '/index.php?error=Kasir tidak ditemukan'); exit; }

$trxCount = mysqli_fetch_assoc(mysqli_query($db, "SELECT COUNT(*) as cnt FROM transactions WHERE cashier_id = $targetId"))['cnt'];
$trxTotal = mysqli_fetch_assoc(mysqli_query($db, "SELECT SUM(grand_total) as total FROM transactions WHERE cashier_id = $targetId"))['total'];

include '../../includes/header.php';
?>
<div class="content">
<div class="d-flex align-center gap-12 mb-16">
    <?php if ($_SESSION['role'] === 'admin' && isset($_GET['id'])): ?>
    <a href="<?= BASE_URL ?>/pages/cashiers/index.php" class="btn btn-secondary btn-sm">← Kembali</a>
    <?php endif; ?>
    <?php if ($targetId == $_SESSION['cashier_id'] || $_SESSION['role'] === 'admin'): ?>
    <a href="<?= BASE_URL ?>/pages/cashiers/edit_profile.php<?= isset($_GET['id']) ? '?id=' . $targetId : '' ?>" class="btn btn-primary btn-sm">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
        Edit Profil
    </a>
    <?php endif; ?>
</div>

<div class="card profile-card">
    <div class="card-header"><span class="card-title">Profil</span></div>
    <div class="card-body">
        <div class="d-flex align-center gap-16 mb-16">
            <div class="profile-avatar-big"><?= strtoupper(substr($cashier['username'], 0, 1)) ?></div>
            <div>
                <div style="font-size:22px;font-weight:800"><?= e($cashier['username']) ?></div>
                <span class="badge <?= $cashier['role'] === 'admin' ? 'badge-red' : 'badge-blue' ?>" style="margin-top:6px">
                    <?= e($cashier['role']) ?>
                </span>
            </div>
        </div>
        <div class="profile-info-row">
            <span class="profile-info-label">Username</span>
            <span class="profile-info-value"><?= e($cashier['username']) ?></span>
        </div>
        <div class="profile-info-row">
            <span class="profile-info-label">Email</span>
            <span class="profile-info-value"><?= e($cashier['email']) ?></span>
        </div>
        <div class="profile-info-row">
            <span class="profile-info-label">Role</span>
            <span class="profile-info-value"><?= e($cashier['role']) ?></span>
        </div>
        <div class="profile-info-row">
            <span class="profile-info-label">Bergabung</span>
            <span class="profile-info-value"><?= date('d F Y', strtotime($cashier['created_at'])) ?></span>
        </div>
        <div class="profile-info-row">
            <span class="profile-info-label">Total Transaksi</span>
            <span class="profile-info-value fw-700"><?= $trxCount ?> transaksi</span>
        </div>
        <div class="profile-info-row">
            <span class="profile-info-label">Total Penjualan</span>
            <span class="profile-info-value fw-700 text-red"><?= formatRupiah($trxTotal ?? 0) ?></span>
        </div>
    </div>
</div>
</div>
<?php include '../../includes/footer.php'; ?>
