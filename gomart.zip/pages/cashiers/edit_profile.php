<?php
require_once '../../config.php';
requireLogin();
$pageTitle = 'Edit Profil';

$db = getDB();
$targetId = isset($_GET['id']) && $_SESSION['role'] === 'admin' ? intval($_GET['id']) : $_SESSION['cashier_id'];

$cashier = mysqli_fetch_assoc(mysqli_query($db, "SELECT * FROM cashiers WHERE id = $targetId LIMIT 1"));
if (!$cashier) { header('Location: ' . BASE_URL . '/index.php?error=Kasir tidak ditemukan'); exit; }
// Non-admin can only edit themselves
if ($_SESSION['role'] !== 'admin' && $targetId !== $_SESSION['cashier_id']) {
    header('Location: ' . BASE_URL . '/pages/cashiers/profile.php');
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? 'profile';

    if ($action === 'profile') {
        $username = sanitize($_POST['username'] ?? '');
        $email = sanitize($_POST['email'] ?? '');
        if (!$username || !$email) {
            $error = 'Username dan email wajib diisi.';
        } else {
            $chk = mysqli_query($db, "SELECT id FROM cashiers WHERE (username='$username' OR email='$email') AND id != $targetId LIMIT 1");
            if (mysqli_num_rows($chk) > 0) {
                $error = 'Username atau email sudah digunakan.';
            } else {
                mysqli_query($db, "UPDATE cashiers SET username='$username', email='$email' WHERE id=$targetId");
                if ($targetId == $_SESSION['cashier_id']) {
                    $_SESSION['username'] = $username;
                    $_SESSION['email'] = $email;
                }
                $success = 'Profil berhasil diupdate.';
                $cashier = mysqli_fetch_assoc(mysqli_query($db, "SELECT * FROM cashiers WHERE id = $targetId LIMIT 1"));
            }
        }
    } elseif ($action === 'password') {
        $oldPass = $_POST['old_password'] ?? '';
        $newPass = $_POST['new_password'] ?? '';
        $newPass2 = $_POST['new_password2'] ?? '';

        if (!$oldPass || !$newPass || !$newPass2) {
            $error = 'Semua field password wajib diisi.';
        } elseif (!password_verify($oldPass, $cashier['password'])) {
            $error = 'Password lama salah.';
        } elseif ($newPass !== $newPass2) {
            $error = 'Password baru tidak cocok.';
        } elseif (strlen($newPass) < 6) {
            $error = 'Password minimal 6 karakter.';
        } else {
            $hash = password_hash($newPass, PASSWORD_BCRYPT);
            mysqli_query($db, "UPDATE cashiers SET password='$hash' WHERE id=$targetId");
            $success = 'Password berhasil diubah.';
            $cashier = mysqli_fetch_assoc(mysqli_query($db, "SELECT * FROM cashiers WHERE id = $targetId LIMIT 1"));
        }
    }
}

include '../../includes/header.php';
?>
<div class="content">
<div class="d-flex align-center gap-12 mb-16">
    <a href="<?= BASE_URL ?>/pages/cashiers/profile.php<?= isset($_GET['id']) ? '?id=' . $targetId : '' ?>" class="btn btn-secondary btn-sm">← Kembali ke Profil</a>
</div>
<?php if ($error): ?>
<div class="alert alert-error mb-16"><?= e($error) ?></div>
<?php endif; ?>
<?php if ($success): ?>
<div class="alert alert-success mb-16"><?= e($success) ?></div>
<?php endif; ?>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;align-items:start">
    <!-- Edit Profile Info -->
    <div class="card">
        <div class="card-header"><span class="card-title">Edit Info Profil</span></div>
        <div class="card-body">
            <form method="POST">
                <input type="hidden" name="action" value="profile">
                <div class="form-group">
                    <label class="form-label">Username <span class="text-red">*</span></label>
                    <input type="text" name="username" class="form-control" value="<?= e($cashier['username']) ?>" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Email <span class="text-red">*</span></label>
                    <input type="email" name="email" class="form-control" value="<?= e($cashier['email']) ?>" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Role</label>
                    <input type="text" class="form-control" value="<?= e($cashier['role']) ?>" disabled>
                    <div class="form-hint">Role hanya bisa diubah oleh admin dari halaman manajemen kasir.</div>
                </div>
                <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
            </form>
        </div>
    </div>

    <!-- Change Password -->
    <div class="card">
        <div class="card-header"><span class="card-title">Ganti Password</span></div>
        <div class="card-body">
            <form method="POST">
                <input type="hidden" name="action" value="password">
                <div class="form-group">
                    <label class="form-label">Password Lama <span class="text-red">*</span></label>
                    <input type="password" name="old_password" class="form-control" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Password Baru <span class="text-red">*</span></label>
                    <input type="password" name="new_password" class="form-control" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Konfirmasi Password Baru <span class="text-red">*</span></label>
                    <input type="password" name="new_password2" class="form-control" required>
                </div>
                <button type="submit" class="btn btn-primary">Ganti Password</button>
            </form>
        </div>
    </div>
</div>
</div>
<?php include '../../includes/footer.php'; ?>
