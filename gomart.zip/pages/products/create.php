<?php
require_once '../../config.php';
requireAdmin();
$pageTitle = 'Tambah Produk';

$db = getDB();
$categories = [];
$res = mysqli_query($db, "SELECT * FROM categories ORDER BY nama");
while ($row = mysqli_fetch_assoc($res)) $categories[] = $row;

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize($_POST['name'] ?? '');
    $cat_id = intval($_POST['category_id'] ?? 0);
    $berat = intval($_POST['berat'] ?? 0);
    $price = floatval($_POST['price'] ?? 0);
    $discount = floatval($_POST['discount'] ?? 0);
    $stock = intval($_POST['stock'] ?? 0);

    if (!$name || !$cat_id || !$berat || !$price) {
        $error = 'Semua field wajib diisi.';
    } else {
        // Generate SKU
        $catRow = mysqli_fetch_assoc(mysqli_query($db, "SELECT * FROM categories WHERE id = $cat_id LIMIT 1"));
        $alias = strtoupper($catRow['alias']);
        $nameClean = strtoupper(preg_replace('/[^a-zA-Z0-9]/', '', $name));
        $namePart = substr($nameClean, 0, 10);
        $sku = $alias . '-' . $namePart . '-' . $berat;

        // Check SKU uniqueness
        $chk = mysqli_query($db, "SELECT id FROM products WHERE sku = '" . mysqli_real_escape_string($db, $sku) . "' LIMIT 1");
        if (mysqli_num_rows($chk) > 0) {
            $error = 'SKU "' . $sku . '" sudah ada. Gunakan nama atau berat yang berbeda.';
        } else {
            $skuEsc = mysqli_real_escape_string($db, $sku);
            $nameEsc = mysqli_real_escape_string($db, $name);
            mysqli_query($db, "INSERT INTO products (name, sku, discount, category_id, berat, price, stock)
                VALUES ('$nameEsc', '$skuEsc', $discount, $cat_id, $berat, $price, $stock)");
            header('Location: ' . BASE_URL . '/pages/products/index.php?success=Produk berhasil ditambahkan');
            exit;
        }
    }
}

include '../../includes/header.php';
?>
<div class="content">
<div class="d-flex align-center gap-12 mb-16">
    <a href="<?= BASE_URL ?>/pages/products/index.php" class="btn btn-secondary btn-sm">← Kembali</a>
</div>
<div class="card" style="max-width:600px">
    <div class="card-header"><span class="card-title">Tambah Produk Baru</span></div>
    <div class="card-body">
        <?php if ($error): ?>
        <div class="alert alert-error mb-16"><?= e($error) ?></div>
        <?php endif; ?>
        <form method="POST">
            <div class="form-group">
                <label class="form-label">Nama Produk <span class="text-red">*</span></label>
                <input type="text" name="name" class="form-control" value="<?= e($_POST['name'] ?? '') ?>" required>
            </div>
            <div class="form-row cols-2">
                <div class="form-group">
                    <label class="form-label">Kategori <span class="text-red">*</span></label>
                    <select name="category_id" class="form-control" required>
                        <option value="">Pilih Kategori</option>
                        <?php foreach ($categories as $cat): ?>
                        <option value="<?= $cat['id'] ?>" <?= (($_POST['category_id'] ?? '') == $cat['id']) ? 'selected' : '' ?>>
                            <?= e($cat['nama']) ?> (<?= e($cat['alias']) ?>)
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Berat (gram) <span class="text-red">*</span></label>
                    <input type="number" name="berat" class="form-control" value="<?= e($_POST['berat'] ?? '') ?>" min="1" required>
                </div>
            </div>
            <div class="form-row cols-2">
                <div class="form-group">
                    <label class="form-label">Harga (Rp) <span class="text-red">*</span></label>
                    <input type="number" name="price" class="form-control" value="<?= e($_POST['price'] ?? '') ?>" min="0" step="100" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Diskon (%)</label>
                    <input type="number" name="discount" class="form-control" value="<?= e($_POST['discount'] ?? '0') ?>" min="0" max="100" step="0.01">
                </div>
            </div>
            <div class="form-group">
                <label class="form-label">Stok Awal</label>
                <input type="number" name="stock" class="form-control" value="<?= e($_POST['stock'] ?? '0') ?>" min="0">
            </div>
            <div class="alert alert-warning mt-8">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                SKU akan digenerate otomatis: <strong>ALIAS-NAMAPRODUCT-BERAT</strong>
            </div>
            <div class="d-flex gap-8 mt-16">
                <button type="submit" class="btn btn-primary">Simpan Produk</button>
                <a href="<?= BASE_URL ?>/pages/products/index.php" class="btn btn-secondary">Batal</a>
            </div>
        </form>
    </div>
</div>
</div>
<?php include '../../includes/footer.php'; ?>
