<?php
require_once '../../config.php';
requireAdmin();
$pageTitle = 'Edit Produk';

$db = getDB();
$id = intval($_GET['id'] ?? 0);
$product = mysqli_fetch_assoc(mysqli_query($db, "SELECT * FROM products WHERE id = $id LIMIT 1"));
if (!$product) { header('Location: ' . BASE_URL . '/pages/products/index.php?error=Produk tidak ditemukan'); exit; }

$categories = [];
$res = mysqli_query($db, "SELECT * FROM categories ORDER BY nama");
while ($row = mysqli_fetch_assoc($res)) $categories[] = $row;

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize($_POST['name'] ?? '');
    $cat_id = intval($_POST['category_id'] ?? 0);
    $berat = intval($_POST['berat'] ?? 0);
    $price = floatval($_POST['price'] ?? 0);
    $discount = floatval($_POST['discount'] ?? 0);
    $stock = intval($_POST['stock'] ?? 0);

    if (!$name || !$cat_id || !$berat || !$price) {
        $error = 'Semua field wajib diisi.';
    } else {
        $catRow = mysqli_fetch_assoc(mysqli_query($db, "SELECT * FROM categories WHERE id = $cat_id LIMIT 1"));
        $alias = strtoupper($catRow['alias']);
        $nameClean = strtoupper(preg_replace('/[^a-zA-Z0-9]/', '', $name));
        $namePart = substr($nameClean, 0, 10);
        $newSku = $alias . '-' . $namePart . '-' . $berat;

        $skuEsc = mysqli_real_escape_string($db, $newSku);
        $chk = mysqli_query($db, "SELECT id FROM products WHERE sku = '$skuEsc' AND id != $id LIMIT 1");
        if (mysqli_num_rows($chk) > 0) {
            $error = 'SKU "' . $newSku . '" sudah digunakan produk lain.';
        } else {
            $nameEsc = mysqli_real_escape_string($db, $name);
            mysqli_query($db, "UPDATE products SET name='$nameEsc', sku='$skuEsc', discount=$discount, category_id=$cat_id, berat=$berat, price=$price, stock=$stock WHERE id=$id");
            header('Location: ' . BASE_URL . '/pages/products/index.php?success=Produk berhasil diupdate');
            exit;
        }
    }
} else {
    $_POST = $product;
}

include '../../includes/header.php';
?>
<div class="content">
<div class="d-flex align-center gap-12 mb-16">
    <a href="<?= BASE_URL ?>/pages/products/index.php" class="btn btn-secondary btn-sm">← Kembali</a>
</div>
<div class="card" style="max-width:600px">
    <div class="card-header">
        <span class="card-title">Edit Produk</span>
        <span class="sku-badge"><?= e($product['sku']) ?></span>
    </div>
    <div class="card-body">
        <?php if ($error): ?>
        <div class="alert alert-error mb-16"><?= e($error) ?></div>
        <?php endif; ?>
        <form method="POST">
            <div class="form-group">
                <label class="form-label">Nama Produk <span class="text-red">*</span></label>
                <input type="text" name="name" class="form-control" value="<?= e($_POST['name'] ?? '') ?>" required>
            </div>
            <div class="form-row cols-2">
                <div class="form-group">
                    <label class="form-label">Kategori <span class="text-red">*</span></label>
                    <select name="category_id" class="form-control" required>
                        <?php foreach ($categories as $cat): ?>
                        <option value="<?= $cat['id'] ?>" <?= (($_POST['category_id'] ?? '') == $cat['id']) ? 'selected' : '' ?>>
                            <?= e($cat['nama']) ?> (<?= e($cat['alias']) ?>)
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Berat (gram) <span class="text-red">*</span></label>
                    <input type="number" name="berat" class="form-control" value="<?= e($_POST['berat'] ?? '') ?>" min="1" required>
                </div>
            </div>
            <div class="form-row cols-2">
                <div class="form-group">
                    <label class="form-label">Harga (Rp) <span class="text-red">*</span></label>
                    <input type="number" name="price" class="form-control" value="<?= e($_POST['price'] ?? '') ?>" min="0" step="100" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Diskon (%)</label>
                    <input type="number" name="discount" class="form-control" value="<?= e($_POST['discount'] ?? '0') ?>" min="0" max="100" step="0.01">
                </div>
            </div>
            <div class="form-group">
                <label class="form-label">Stok</label>
                <input type="number" name="stock" class="form-control" value="<?= e($_POST['stock'] ?? '0') ?>" min="0">
            </div>
            <div class="form-group">
                <label class="form-label text-muted">Terjual</label>
                <input type="text" class="form-control" value="<?= $product['sold'] ?>" disabled>
            </div>
            <div class="d-flex gap-8 mt-16">
                <button type="submit" class="btn btn-primary">Update Produk</button>
                <a href="<?= BASE_URL ?>/pages/products/index.php" class="btn btn-secondary">Batal</a>
            </div>
        </form>
    </div>
</div>
</div>
<?php include '../../includes/footer.php'; ?>
