<?php
require_once '../../config.php';
requireAdmin();
$pageTitle = 'Manajemen Produk';

$db = getDB();

// Handle delete
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    mysqli_query($db, "DELETE FROM products WHERE id = $id");
    header('Location: ' . BASE_URL . '/pages/products/index.php?success=Produk berhasil dihapus');
    exit;
}

// Pagination
$perPage = 20;
$page = max(1, intval($_GET['page'] ?? 1));
$offset = ($page - 1) * $perPage;
$search = sanitize($_GET['q'] ?? '');
$catFilter = intval($_GET['cat'] ?? 0);

$where = "WHERE 1=1";
if ($search) $where .= " AND (p.name LIKE '%$search%' OR p.sku LIKE '%$search%')";
if ($catFilter) $where .= " AND p.category_id = $catFilter";

$total = mysqli_fetch_assoc(mysqli_query($db, "SELECT COUNT(*) as cnt FROM products p $where"))['cnt'];
$totalPages = ceil($total / $perPage);

$products = [];
$res = mysqli_query($db, "SELECT p.*, c.nama as cat_name, c.alias as cat_alias FROM products p JOIN categories c ON p.category_id = c.id $where ORDER BY p.name LIMIT $perPage OFFSET $offset");
while ($row = mysqli_fetch_assoc($res)) $products[] = $row;

$categories = [];
$res2 = mysqli_query($db, "SELECT * FROM categories ORDER BY nama");
while ($row = mysqli_fetch_assoc($res2)) $categories[] = $row;

include '../../includes/header.php';
?>
<div class="content">
<div class="card">
    <div class="card-header">
        <span class="card-title">Daftar Produk (<?= $total ?>)</span>
        <div class="d-flex gap-8 align-center" style="flex-wrap:wrap">
            <form method="GET" class="d-flex gap-8 align-center" style="flex-wrap:wrap">
                <div class="search-bar">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                    <input type="text" name="q" value="<?= e($search) ?>" placeholder="Cari produk/SKU...">
                </div>
                <select name="cat" class="form-control" style="width:auto;padding:8px 12px">
                    <option value="">Semua Kategori</option>
                    <?php foreach ($categories as $cat): ?>
                    <option value="<?= $cat['id'] ?>" <?= $catFilter == $cat['id'] ? 'selected' : '' ?>><?= e($cat['nama']) ?></option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="btn btn-secondary btn-sm">Filter</button>
            </form>
            <a href="<?= BASE_URL ?>/pages/products/create.php" class="btn btn-primary btn-sm">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                Tambah Produk
            </a>
        </div>
    </div>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>SKU</th>
                    <th>Nama</th>
                    <th>Kategori</th>
                    <th>Berat</th>
                    <th>Harga</th>
                    <th>Diskon</th>
                    <th>Stok</th>
                    <th>Terjual</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($products)): ?>
                <tr><td colspan="10" class="no-results">Tidak ada produk ditemukan</td></tr>
                <?php else: ?>
                <?php foreach ($products as $i => $p): ?>
                <tr>
                    <td class="text-muted"><?= $offset + $i + 1 ?></td>
                    <td><span class="sku-badge"><?= e($p['sku']) ?></span></td>
                    <td class="fw-700"><?= e($p['name']) ?></td>
                    <td><span class="badge badge-blue"><?= e($p['cat_name']) ?></span></td>
                    <td class="text-muted"><?= $p['berat'] ?>g</td>
                    <td class="fw-700"><?= formatRupiah($p['price']) ?></td>
                    <td><?= $p['discount'] > 0 ? '<span class="badge badge-red">' . $p['discount'] . '%</span>' : '-' ?></td>
                    <td class="<?= $p['stock'] <= 0 ? 'stock-out fw-700' : ($p['stock'] <= 10 ? 'stock-low' : '') ?>"><?= $p['stock'] ?></td>
                    <td><?= $p['sold'] ?></td>
                    <td>
                        <div class="btn-group">
                            <a href="<?= BASE_URL ?>/pages/products/edit.php?id=<?= $p['id'] ?>" class="btn btn-secondary btn-sm">Edit</a>
                            <button class="btn btn-danger btn-sm" onclick="confirmDelete('<?= BASE_URL ?>/pages/products/index.php?delete=<?= $p['id'] ?>', 'Hapus produk <?= e(addslashes($p['name'])) ?>?')">Hapus</button>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if ($totalPages > 1): ?>
    <div style="padding:16px">
        <div class="pagination">
            <?php if ($page > 1): ?>
            <a href="?page=<?= $page-1 ?>&q=<?= e($search) ?>&cat=<?= $catFilter ?>" class="page-btn">‹</a>
            <?php endif; ?>
            <?php for ($i = max(1,$page-2); $i <= min($totalPages,$page+2); $i++): ?>
            <a href="?page=<?= $i ?>&q=<?= e($search) ?>&cat=<?= $catFilter ?>" class="page-btn <?= $i == $page ? 'active' : '' ?>"><?= $i ?></a>
            <?php endfor; ?>
            <?php if ($page < $totalPages): ?>
            <a href="?page=<?= $page+1 ?>&q=<?= e($search) ?>&cat=<?= $catFilter ?>" class="page-btn">›</a>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>
</div>
</div>
<?php include '../../includes/footer.php'; ?>
