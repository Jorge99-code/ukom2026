<?php
require_once '../../config.php';
requireLogin();
$pageTitle = 'Detail Transaksi';

$db = getDB();
$id = intval($_GET['id'] ?? 0);

$where = "WHERE t.id = $id";
if ($_SESSION['role'] !== 'admin') $where .= " AND t.cashier_id = " . $_SESSION['cashier_id'];

$trx = mysqli_fetch_assoc(mysqli_query($db, "SELECT t.*, c.username as cashier_name FROM transactions t JOIN cashiers c ON t.cashier_id = c.id $where LIMIT 1"));
if (!$trx) { header('Location: ' . BASE_URL . '/pages/transactions/index.php?error=Transaksi tidak ditemukan'); exit; }

$items = [];
$res = mysqli_query($db, "SELECT * FROM transaction_items WHERE transaction_id = $id");
while ($row = mysqli_fetch_assoc($res)) $items[] = $row;

include '../../includes/header.php';
?>
<div class="content">
<div class="d-flex align-center gap-12 mb-16">
    <a href="<?= BASE_URL ?>/pages/transactions/index.php" class="btn btn-secondary btn-sm">← Kembali</a>
    <button class="btn btn-primary btn-sm" onclick="printReceipt()">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
        Print Struk
    </button>
</div>

<div style="display:grid;grid-template-columns:1fr 340px;gap:20px;align-items:start">
    <!-- Items -->
    <div class="card">
        <div class="card-header">
            <span class="card-title">Item Transaksi</span>
            <span class="sku-badge"><?= e($trx['kode']) ?></span>
        </div>
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>SKU</th>
                        <th>Nama Produk</th>
                        <th>Harga</th>
                        <th>Diskon</th>
                        <th>Qty</th>
                        <th>Subtotal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($items as $i => $item): ?>
                    <tr>
                        <td class="text-muted"><?= $i+1 ?></td>
                        <td><span class="sku-badge"><?= e($item['product_sku']) ?></span></td>
                        <td><?= e($item['product_name']) ?></td>
                        <td><?= formatRupiah($item['price']) ?></td>
                        <td><?= $item['discount'] > 0 ? '<span class="badge badge-red">' . $item['discount'] . '%</span>' : '-' ?></td>
                        <td class="fw-700"><?= $item['qty'] ?></td>
                        <td class="fw-700 text-red"><?= formatRupiah($item['subtotal']) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Summary + Receipt -->
    <div>
        <div class="card mb-16">
            <div class="card-header"><span class="card-title">Ringkasan</span></div>
            <div class="card-body">
                <div class="profile-info-row"><span class="profile-info-label">Kode</span><span class="profile-info-value font-mono"><?= e($trx['kode']) ?></span></div>
                <div class="profile-info-row"><span class="profile-info-label">Tanggal</span><span class="profile-info-value"><?= date('d/m/Y H:i', strtotime($trx['created_at'])) ?></span></div>
                <div class="profile-info-row"><span class="profile-info-label">Kasir</span><span class="profile-info-value"><?= e($trx['cashier_name']) ?></span></div>
                <div class="profile-info-row"><span class="profile-info-label">Total</span><span class="profile-info-value text-red"><?= formatRupiah($trx['grand_total']) ?></span></div>
                <div class="profile-info-row"><span class="profile-info-label">Dibayar</span><span class="profile-info-value"><?= formatRupiah($trx['amount_paid']) ?></span></div>
                <div class="profile-info-row"><span class="profile-info-label">Kembalian</span><span class="profile-info-value text-green"><?= formatRupiah($trx['change_amount']) ?></span></div>
            </div>
        </div>
    </div>
</div>

<!-- Hidden receipt -->
<div style="display:none" id="receipt-content">
    <div class="receipt">
        <div class="receipt-header">
            <h2><?= STORE_NAME ?></h2>
            <p><?= STORE_LOCATION ?></p>
            <hr class="receipt-divider">
            <p><?= date('d/m/Y H:i:s', strtotime($trx['created_at'])) ?></p>
            <p>No: <?= e($trx['kode']) ?></p>
            <p>Kasir: <?= e($trx['cashier_name']) ?></p>
        </div>
        <hr class="receipt-divider">
        <?php foreach ($items as $item): ?>
        <div class="receipt-row">
            <span><?= e($item['product_name']) ?> x<?= $item['qty'] ?></span>
            <span><?= formatRupiah($item['subtotal']) ?></span>
        </div>
        <?php if ($item['discount'] > 0): ?>
        <div class="receipt-row" style="color:#999;font-size:11px">
            <span>  Diskon <?= $item['discount'] ?>%</span>
            <span>-<?= formatRupiah($item['price'] * $item['discount'] / 100 * $item['qty']) ?></span>
        </div>
        <?php endif; ?>
        <?php endforeach; ?>
        <hr class="receipt-divider">
        <div class="receipt-total-section">
            <div class="receipt-total-row"><span>Total</span><span><?= formatRupiah($trx['grand_total']) ?></span></div>
            <div class="receipt-row"><span>Bayar</span><span><?= formatRupiah($trx['amount_paid']) ?></span></div>
            <div class="receipt-row"><span>Kembalian</span><span><?= formatRupiah($trx['change_amount']) ?></span></div>
        </div>
        <hr class="receipt-divider">
        <div style="text-align:center;margin-top:8px">
            <p>Terima kasih telah berbelanja!</p>
            <p>*Barang yang sudah dibeli tidak dapat dikembalikan*</p>
        </div>
    </div>
</div>
</div>
<?php include '../../includes/footer.php'; ?>
