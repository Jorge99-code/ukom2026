<?php
require_once '../../config.php';
requireLogin();
$pageTitle = 'Riwayat Transaksi';

$db = getDB();

// Handle delete (admin only)
if (isset($_GET['delete']) && $_SESSION['role'] === 'admin') {
    $id = intval($_GET['delete']);
    mysqli_query($db, "DELETE FROM transactions WHERE id = $id");
    header('Location: ' . BASE_URL . '/pages/transactions/index.php?success=Transaksi berhasil dihapus');
    exit;
}

$perPage = 20;
$page = max(1, intval($_GET['page'] ?? 1));
$offset = ($page - 1) * $perPage;
$search = sanitize($_GET['q'] ?? '');
$dateFrom = sanitize($_GET['from'] ?? '');
$dateTo = sanitize($_GET['to'] ?? '');

$where = "WHERE 1=1";
if ($search) $where .= " AND (t.kode LIKE '%$search%' OR c.username LIKE '%$search%')";
if ($dateFrom) $where .= " AND DATE(t.created_at) >= '$dateFrom'";
if ($dateTo) $where .= " AND DATE(t.created_at) <= '$dateTo'";
// Non-admin can only see their own
if ($_SESSION['role'] !== 'admin') $where .= " AND t.cashier_id = " . $_SESSION['cashier_id'];

$total = mysqli_fetch_assoc(mysqli_query($db, "SELECT COUNT(*) as cnt FROM transactions t JOIN cashiers c ON t.cashier_id = c.id $where"))['cnt'];
$totalPages = ceil($total / $perPage);
$grandSum = mysqli_fetch_assoc(mysqli_query($db, "SELECT SUM(grand_total) as total FROM transactions t JOIN cashiers c ON t.cashier_id = c.id $where"))['total'];

$transactions = [];
$res = mysqli_query($db, "SELECT t.*, c.username as cashier_name FROM transactions t JOIN cashiers c ON t.cashier_id = c.id $where ORDER BY t.created_at DESC LIMIT $perPage OFFSET $offset");
while ($row = mysqli_fetch_assoc($res)) $transactions[] = $row;

include '../../includes/header.php';
?>
<div class="content">
<div class="stats-grid" style="grid-template-columns:repeat(auto-fit,minmax(160px,1fr));margin-bottom:20px">
    <div class="stat-card">
        <div class="stat-icon blue"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg></div>
        <div class="stat-label">Total Transaksi</div>
        <div class="stat-value"><?= $total ?></div>
    </div>
    <div class="stat-card">
        <div class="stat-icon green"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg></div>
        <div class="stat-label">Total Pendapatan</div>
        <div class="stat-value" style="font-size:16px"><?= formatRupiah($grandSum ?? 0) ?></div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <span class="card-title">Daftar Transaksi</span>
        <form method="GET" class="d-flex gap-8 align-center" style="flex-wrap:wrap">
            <div class="search-bar">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                <input type="text" name="q" value="<?= e($search) ?>" placeholder="Cari kode/kasir...">
            </div>
            <input type="date" name="from" class="form-control" style="width:auto" value="<?= e($dateFrom) ?>">
            <input type="date" name="to" class="form-control" style="width:auto" value="<?= e($dateTo) ?>">
            <button type="submit" class="btn btn-secondary btn-sm">Filter</button>
            <?php if ($search || $dateFrom || $dateTo): ?>
            <a href="<?= BASE_URL ?>/pages/transactions/index.php" class="btn btn-secondary btn-sm">Reset</a>
            <?php endif; ?>
        </form>
    </div>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Kode</th>
                    <th>Tanggal</th>
                    <th>Kasir</th>
                    <th>Total</th>
                    <th>Bayar</th>
                    <th>Kembalian</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($transactions)): ?>
                <tr><td colspan="8" class="no-results">Tidak ada transaksi ditemukan</td></tr>
                <?php else: ?>
                <?php foreach ($transactions as $i => $t): ?>
                <tr>
                    <td class="text-muted"><?= $offset + $i + 1 ?></td>
                    <td><span class="sku-badge"><?= e($t['kode']) ?></span></td>
                    <td class="text-muted"><?= date('d/m/Y H:i', strtotime($t['created_at'])) ?></td>
                    <td><?= e($t['cashier_name']) ?></td>
                    <td class="fw-700 text-red"><?= formatRupiah($t['grand_total']) ?></td>
                    <td><?= formatRupiah($t['amount_paid']) ?></td>
                    <td class="text-green"><?= formatRupiah($t['change_amount']) ?></td>
                    <td>
                        <div class="btn-group">
                            <a href="<?= BASE_URL ?>/pages/transactions/detail.php?id=<?= $t['id'] ?>" class="btn btn-outline btn-sm">Detail</a>
                            <?php if ($_SESSION['role'] === 'admin'): ?>
                            <button class="btn btn-danger btn-sm" onclick="confirmDelete('<?= BASE_URL ?>/pages/transactions/index.php?delete=<?= $t['id'] ?>', 'Hapus transaksi <?= e($t['kode']) ?>?')">Hapus</button>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if ($totalPages > 1): ?>
    <div style="padding:16px">
        <div class="pagination">
            <?php if ($page > 1): ?>
            <a href="?page=<?= $page-1 ?>&q=<?= e($search) ?>&from=<?= e($dateFrom) ?>&to=<?= e($dateTo) ?>" class="page-btn">‹</a>
            <?php endif; ?>
            <?php for ($i = max(1,$page-2); $i <= min($totalPages,$page+2); $i++): ?>
            <a href="?page=<?= $i ?>&q=<?= e($search) ?>&from=<?= e($dateFrom) ?>&to=<?= e($dateTo) ?>" class="page-btn <?= $i == $page ? 'active' : '' ?>"><?= $i ?></a>
            <?php endfor; ?>
            <?php if ($page < $totalPages): ?>
            <a href="?page=<?= $page+1 ?>&q=<?= e($search) ?>&from=<?= e($dateFrom) ?>&to=<?= e($dateTo) ?>" class="page-btn">›</a>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>
</div>
</div>
<?php include '../../includes/footer.php'; ?>
