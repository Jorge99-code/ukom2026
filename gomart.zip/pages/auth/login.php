<?php
require_once '../../config.php';

if (isLoggedIn()) {
    header('Location: ' . BASE_URL . '/index.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitize($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username && $password) {
        $db = getDB();
        $result = mysqli_query($db, "SELECT * FROM cashiers WHERE username = '$username' LIMIT 1");
        $user = mysqli_fetch_assoc($result);
        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['cashier_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['role'] = $user['role'];
            header('Location: ' . BASE_URL . '/index.php');
            exit;
        } else {
            $error = 'Username atau password salah.';
        }
    } else {
        $error = 'Semua field wajib diisi.';
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - <?= STORE_NAME ?></title>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= BASE_URL ?>/css/style.css">
</head>
<body>
<div class="auth-page">
    <div class="auth-card">
        <div class="auth-logo">
            <svg width="52" height="52" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect width="32" height="32" rx="8" fill="#FF0000"/>
                <path d="M6 12h20M6 12l2-4h16l2 4M6 12v12h20V12" stroke="white" stroke-width="1.8" stroke-linejoin="round"/>
                <path d="M12 18h8M12 22h5" stroke="white" stroke-width="1.8" stroke-linecap="round"/>
                <circle cx="10" cy="27" r="2" fill="white"/>
                <circle cx="22" cy="27" r="2" fill="white"/>
            </svg>
            <h1><?= STORE_NAME ?></h1>
            <p><?= STORE_LOCATION ?></p>
        </div>
        <?php if ($error): ?>
        <div class="alert alert-error" style="margin-bottom:16px"><?= e($error) ?></div>
        <?php endif; ?>
        <form method="POST">
            <div class="form-group">
                <label class="form-label">Username</label>
                <input type="text" name="username" class="form-control" placeholder="Masukkan username" value="<?= e($_POST['username'] ?? '') ?>" autofocus required>
            </div>
            <div class="form-group">
                <label class="form-label">Password</label>
                <input type="password" name="password" class="form-control" placeholder="Masukkan password" required>
            </div>
            <button type="submit" class="btn btn-primary w-100 btn-lg">Masuk</button>
        </form>
        <div class="auth-footer">
            Belum punya akun? <a href="<?= BASE_URL ?>/pages/auth/register.php">Daftar di sini</a>
        </div>
    </div>
</div>
</body>
</html>
