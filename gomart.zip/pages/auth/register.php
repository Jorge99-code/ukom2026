<?php
require_once '../../config.php';

if (isLoggedIn()) {
    header('Location: ' . BASE_URL . '/index.php');
    exit;
}

$error = '';
$success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitize($_POST['username'] ?? '');
    $email = sanitize($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $password2 = $_POST['password2'] ?? '';
    $secret = $_POST['secret'] ?? '';

    if (!$username || !$email || !$password || !$secret) {
        $error = 'Semua field wajib diisi.';
    } elseif ($password !== $password2) {
        $error = 'Password tidak cocok.';
    } elseif (strlen($password) < 6) {
        $error = 'Password minimal 6 karakter.';
    } elseif ($secret !== STORE_SECRET) {
        $error = 'Secret key salah. Hubungi admin.';
    } else {
        $db = getDB();
        $chk = mysqli_query($db, "SELECT id FROM cashiers WHERE username='$username' OR email='$email' LIMIT 1");
        if (mysqli_num_rows($chk) > 0) {
            $error = 'Username atau email sudah terdaftar.';
        } else {
            $hash = password_hash($password, PASSWORD_BCRYPT);
            mysqli_query($db, "INSERT INTO cashiers (username, email, password, role) VALUES ('$username', '$email', '$hash', 'cashier')");
            $success = 'Akun berhasil dibuat! Silakan login.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar - <?= STORE_NAME ?></title>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= BASE_URL ?>/css/style.css">
</head>
<body>
<div class="auth-page">
    <div class="auth-card">
        <div class="auth-logo">
            <svg width="52" height="52" viewBox="0 0 32 32" fill="none">
                <rect width="32" height="32" rx="8" fill="#FF0000"/>
                <path d="M6 12h20M6 12l2-4h16l2 4M6 12v12h20V12" stroke="white" stroke-width="1.8" stroke-linejoin="round"/>
                <path d="M12 18h8M12 22h5" stroke="white" stroke-width="1.8" stroke-linecap="round"/>
                <circle cx="10" cy="27" r="2" fill="white"/>
                <circle cx="22" cy="27" r="2" fill="white"/>
            </svg>
            <h1><?= STORE_NAME ?></h1>
            <p>Daftar Akun Kasir</p>
        </div>
        <?php if ($error): ?>
        <div class="alert alert-error" style="margin-bottom:16px"><?= e($error) ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
        <div class="alert alert-success" style="margin-bottom:16px"><?= e($success) ?></div>
        <?php endif; ?>
        <form method="POST">
            <div class="form-group">
                <label class="form-label">Username</label>
                <input type="text" name="username" class="form-control" placeholder="Username" value="<?= e($_POST['username'] ?? '') ?>" required>
            </div>
            <div class="form-group">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-control" placeholder="Email" value="<?= e($_POST['email'] ?? '') ?>" required>
            </div>
            <div class="form-row cols-2">
                <div class="form-group">
                    <label class="form-label">Password</label>
                    <input type="password" name="password" class="form-control" placeholder="Password" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Konfirmasi Password</label>
                    <input type="password" name="password2" class="form-control" placeholder="Ulangi password" required>
                </div>
            </div>
            <div class="form-group">
                <label class="form-label">Secret Key</label>
                <input type="text" name="secret" class="form-control" placeholder="Minta ke admin" required>
                <div class="form-hint">Diperlukan untuk mendaftar. Hubungi admin untuk mendapatkan secret key.</div>
            </div>
            <button type="submit" class="btn btn-primary w-100 btn-lg">Daftar</button>
        </form>
        <div class="auth-footer">
            Sudah punya akun? <a href="<?= BASE_URL ?>/pages/auth/login.php">Login di sini</a>
        </div>
    </div>
</div>
</body>
</html>
