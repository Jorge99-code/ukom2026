<?php
require_once '../../config.php';
requireAdmin();
$pageTitle = 'Manajemen Kategori';

$db = getDB();
$error = '';

// Handle delete
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $chk = mysqli_fetch_assoc(mysqli_query($db, "SELECT COUNT(*) as cnt FROM products WHERE category_id = $id"));
    if ($chk['cnt'] > 0) {
        $error = 'Kategori tidak bisa dihapus karena masih ada produk yang menggunakan kategori ini.';
    } else {
        mysqli_query($db, "DELETE FROM categories WHERE id = $id");
        header('Location: ' . BASE_URL . '/pages/categories/index.php?success=Kategori berhasil dihapus');
        exit;
    }
}

// Handle create/edit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = sanitize($_POST['nama'] ?? '');
    $alias = strtoupper(sanitize($_POST['alias'] ?? ''));
    $editId = intval($_POST['edit_id'] ?? 0);

    if (!$nama || strlen($alias) !== 3) {
        $error = 'Nama wajib diisi dan alias harus tepat 3 karakter.';
    } else {
        $chk = mysqli_query($db, "SELECT id FROM categories WHERE alias = '$alias'" . ($editId ? " AND id != $editId" : "") . " LIMIT 1");
        if (mysqli_num_rows($chk) > 0) {
            $error = 'Alias sudah digunakan kategori lain.';
        } else {
            if ($editId) {
                mysqli_query($db, "UPDATE categories SET nama='$nama', alias='$alias' WHERE id=$editId");
                header('Location: ' . BASE_URL . '/pages/categories/index.php?success=Kategori berhasil diupdate');
            } else {
                mysqli_query($db, "INSERT INTO categories (nama, alias) VALUES ('$nama', '$alias')");
                header('Location: ' . BASE_URL . '/pages/categories/index.php?success=Kategori berhasil ditambahkan');
            }
            exit;
        }
    }
}

// Get edit target
$editCat = null;
if (isset($_GET['edit'])) {
    $editCat = mysqli_fetch_assoc(mysqli_query($db, "SELECT * FROM categories WHERE id = " . intval($_GET['edit']) . " LIMIT 1"));
}

$categories = [];
$res = mysqli_query($db, "SELECT c.*, COUNT(p.id) as product_count FROM categories c LEFT JOIN products p ON c.id = p.category_id GROUP BY c.id ORDER BY c.nama");
while ($row = mysqli_fetch_assoc($res)) $categories[] = $row;

include '../../includes/header.php';
?>
<div class="content">
<div style="display:grid;grid-template-columns:1fr 340px;gap:20px;align-items:start">
    <!-- List -->
    <div class="card">
        <div class="card-header"><span class="card-title">Daftar Kategori (<?= count($categories) ?>)</span></div>
        <?php if ($error): ?>
        <div class="alert alert-error" style="margin:12px 20px 0"><?= e($error) ?></div>
        <?php endif; ?>
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nama</th>
                        <th>Alias</th>
                        <th>Jumlah Produk</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($categories)): ?>
                    <tr><td colspan="5" class="no-results">Belum ada kategori</td></tr>
                    <?php else: ?>
                    <?php foreach ($categories as $i => $cat): ?>
                    <tr>
                        <td class="text-muted"><?= $i+1 ?></td>
                        <td class="fw-700"><?= e($cat['nama']) ?></td>
                        <td><span class="badge badge-blue font-mono"><?= e($cat['alias']) ?></span></td>
                        <td><?= $cat['product_count'] ?> produk</td>
                        <td>
                            <div class="btn-group">
                                <a href="?edit=<?= $cat['id'] ?>" class="btn btn-secondary btn-sm">Edit</a>
                                <?php if ($cat['product_count'] == 0): ?>
                                <button class="btn btn-danger btn-sm" onclick="confirmDelete('<?= BASE_URL ?>/pages/categories/index.php?delete=<?= $cat['id'] ?>', 'Hapus kategori <?= e(addslashes($cat['nama'])) ?>?')">Hapus</button>
                                <?php else: ?>
                                <button class="btn btn-secondary btn-sm" disabled title="Ada produk">Hapus</button>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Form -->
    <div class="card">
        <div class="card-header"><span class="card-title"><?= $editCat ? 'Edit Kategori' : 'Tambah Kategori' ?></span></div>
        <div class="card-body">
            <form method="POST">
                <?php if ($editCat): ?>
                <input type="hidden" name="edit_id" value="<?= $editCat['id'] ?>">
                <?php endif; ?>
                <div class="form-group">
                    <label class="form-label">Nama Kategori <span class="text-red">*</span></label>
                    <input type="text" name="nama" class="form-control" value="<?= e($editCat ? $editCat['nama'] : ($_POST['nama'] ?? '')) ?>" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Alias SKU (3 karakter) <span class="text-red">*</span></label>
                    <input type="text" name="alias" class="form-control font-mono" maxlength="3" style="text-transform:uppercase" value="<?= e($editCat ? $editCat['alias'] : ($_POST['alias'] ?? '')) ?>" required placeholder="cth: MNM">
                    <div class="form-hint">Digunakan sebagai prefix SKU produk</div>
                </div>
                <div class="d-flex gap-8">
                    <button type="submit" class="btn btn-primary"><?= $editCat ? 'Update' : 'Tambah' ?></button>
                    <?php if ($editCat): ?>
                    <a href="<?= BASE_URL ?>/pages/categories/index.php" class="btn btn-secondary">Batal</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>
</div>
</div>
<?php include '../../includes/footer.php'; ?>
