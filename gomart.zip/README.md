# GoMart POS

POS System untuk minimarket GoMart - Jatiwarna, Bekasi

## Stack
- PHP 7.2 Native (no framework)
- MySQL 5.7
- Apache2
- Vanilla JS + CSS

## Setup dengan Docker

```bash
docker-compose up -d
```

Akses:
- App: http://localhost:8080
- phpMyAdmin: http://localhost:8081

## Setup dengan XAMPP

1. Copy folder `gomart` ke `htdocs/`
2. Import `database.sql` ke MySQL via phpMyAdmin
3. Edit `config.php` jika perlu sesuaikan `DB_HOST`, `DB_USER`, `DB_PASS`
4. Akses: http://localhost/gomart

## Default Account

| Username | Password | Role  |
|----------|----------|-------|
| admin    | password | admin |

## Fitur

- **Kasir (POS)**: Input produk via klik atau SKU, keranjang, pembayaran, cetak struk
- **Produk**: CRUD produk, SKU auto-generate (ALIAS-NAMA-BERAT), filter & search
- **Kategori**: CRUD kategori dengan alias 3 karakter untuk SKU
- **Transaksi**: Riwayat transaksi, filter tanggal, print/download struk
- **Kasir**: Manajemen akun kasir, atur role (admin/cashier)
- **Profil**: View & edit profil, ganti password
- **Auth**: Login, register (butuh secret key = nama store)

## Secret Key Registrasi

Default: `GoMart` (sama dengan nama store)

Bisa diubah via env variable `STORE_SECRET`.

## SKU Format

```
{ALIAS_KATEGORI}-{NAMAPRODUCT}-{BERAT}
Contoh: MNM-AQUABOTOL-600
```
