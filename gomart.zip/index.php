<?php
require_once 'config.php';
$pageTitle = 'Kasir';

// Handle checkout POST
$receiptData = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cart'])) {
    $cartRaw = $_POST['cart'] ?? '[]';
    $cartItems = json_decode($cartRaw, true);
    $amountPaid = floatval($_POST['amount_paid'] ?? 0);

    if (!empty($cartItems) && $amountPaid > 0) {
        $db = getDB();
        $grandTotal = 0;
        $validItems = [];

        foreach ($cartItems as $item) {
            $pid = intval($item['id']);
            $qty = intval($item['qty']);
            $res = mysqli_query($db, "SELECT * FROM products WHERE id = $pid AND stock >= $qty LIMIT 1");
            $prod = mysqli_fetch_assoc($res);
            if ($prod) {
                $discPrice = $prod['price'] * (1 - $prod['discount'] / 100);
                $sub = $discPrice * $qty;
                $grandTotal += $sub;
                $validItems[] = [
                    'product' => $prod,
                    'qty' => $qty,
                    'price' => $prod['price'],
                    'discount' => $prod['discount'],
                    'subtotal' => $sub
                ];
            }
        }

        if (!empty($validItems) && $amountPaid >= $grandTotal) {
            $change = $amountPaid - $grandTotal;
            $kode = generateTrxCode();
            $cashierId = $_SESSION['cashier_id'];
            $gtEsc = mysqli_real_escape_string($db, $grandTotal);
            $paidEsc = mysqli_real_escape_string($db, $amountPaid);
            $changeEsc = mysqli_real_escape_string($db, $change);
            $kodeEsc = mysqli_real_escape_string($db, $kode);

            mysqli_query($db, "INSERT INTO transactions (kode, cashier_id, grand_total, amount_paid, change_amount)
                VALUES ('$kodeEsc', $cashierId, $gtEsc, $paidEsc, $changeEsc)");
            $trxId = mysqli_insert_id($db);

            foreach ($validItems as $vi) {
                $prod = $vi['product'];
                $nameEsc = mysqli_real_escape_string($db, $prod['name']);
                $skuEsc = mysqli_real_escape_string($db, $prod['sku']);
                mysqli_query($db, "INSERT INTO transaction_items (transaction_id, product_id, product_name, product_sku, qty, price, discount, subtotal)
                    VALUES ($trxId, {$prod['id']}, '$nameEsc', '$skuEsc', {$vi['qty']}, {$vi['price']}, {$vi['discount']}, {$vi['subtotal']})");
                mysqli_query($db, "UPDATE products SET stock = stock - {$vi['qty']}, sold = sold + {$vi['qty']} WHERE id = {$prod['id']}");
            }

            $receiptData = [
                'kode' => $kode,
                'items' => $validItems,
                'grand_total' => $grandTotal,
                'amount_paid' => $amountPaid,
                'change' => $change,
                'cashier' => $_SESSION['username'],
                'created_at' => date('d/m/Y H:i:s')
            ];
        }
    }
}

// Get products
$db = getDB();
$products = [];
$res = mysqli_query($db, "SELECT p.*, c.nama as cat_name FROM products p JOIN categories c ON p.category_id = c.id ORDER BY c.nama, p.name");
while ($row = mysqli_fetch_assoc($res)) $products[] = $row;

include 'includes/header.php';
?>
<div class="content">
<?php if ($receiptData): ?>
<!-- Receipt Modal - auto open after transaction -->
<div class="modal-overlay active" id="receiptModal">
    <div class="modal" style="max-width:420px">
        <div class="modal-header">
            <span class="modal-title text-green">✓ Transaksi Berhasil!</span>
            <button class="modal-close" onclick="closeModal('receiptModal')">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            </button>
        </div>
        <div class="modal-body" style="padding:0 20px 16px">
            <div id="receipt-content">
                <div class="receipt">
                    <div class="receipt-header">
                        <h2><?= STORE_NAME ?></h2>
                        <p><?= STORE_LOCATION ?></p>
                        <hr class="receipt-divider">
                        <p><?= $receiptData['created_at'] ?></p>
                        <p>No: <?= e($receiptData['kode']) ?></p>
                        <p>Kasir: <?= e($receiptData['cashier']) ?></p>
                    </div>
                    <hr class="receipt-divider">
                    <?php foreach ($receiptData['items'] as $item): ?>
                    <div class="receipt-row">
                        <span><?= e($item['product']['name']) ?> x<?= $item['qty'] ?></span>
                        <span><?= formatRupiah($item['subtotal']) ?></span>
                    </div>
                    <?php if ($item['discount'] > 0): ?>
                    <div class="receipt-row" style="color:#999;font-size:11px">
                        <span>&nbsp;&nbsp;Diskon <?= $item['discount'] ?>%</span>
                        <span>-<?= formatRupiah($item['product']['price'] * $item['discount'] / 100 * $item['qty']) ?></span>
                    </div>
                    <?php endif; ?>
                    <?php endforeach; ?>
                    <hr class="receipt-divider">
                    <div class="receipt-total-section">
                        <div class="receipt-total-row"><span>Total</span><span><?= formatRupiah($receiptData['grand_total']) ?></span></div>
                        <div class="receipt-row"><span>Bayar</span><span><?= formatRupiah($receiptData['amount_paid']) ?></span></div>
                        <div class="receipt-row"><span>Kembalian</span><span><?= formatRupiah($receiptData['change']) ?></span></div>
                    </div>
                    <hr class="receipt-divider">
                    <div style="text-align:center;margin-top:8px">
                        <p>Terima kasih telah berbelanja!</p>
                        <p>*Barang yang sudah dibeli tidak dapat dikembalikan*</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="printReceipt()">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
                Print Struk
            </button>
            <button class="btn btn-primary" onclick="closeModal('receiptModal')">Tutup & Lanjut</button>
        </div>
    </div>
</div>
<?php endif; ?>

<div class="pos-layout">
    <!-- Left: Products -->
    <div class="pos-left">
        <div class="d-flex gap-8 align-center">
            <div class="pos-search" style="flex:1">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                <input type="text" id="productSearch" placeholder="Cari produk..." oninput="filterProducts()">
            </div>
            <div style="position:relative;flex:1">
                <div class="pos-search" style="max-width:100%">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>
                    <input type="text" id="skuInput" placeholder="Input SKU lalu Enter..." class="mono">
                </div>
                <div id="skuError" style="display:none;color:var(--danger);font-size:12px;margin-top:4px;position:absolute"></div>
            </div>
        </div>
        <div class="pos-products" id="productGrid">
            <?php foreach ($products as $p): ?>
            <div class="product-card <?= $p['stock'] <= 0 ? 'out-of-stock' : '' ?>"
                 data-id="<?= $p['id'] ?>"
                 data-name="<?= e($p['name']) ?>"
                 data-sku="<?= e($p['sku']) ?>"
                 data-price="<?= $p['price'] ?>"
                 data-discount="<?= $p['discount'] ?>"
                 data-stock="<?= $p['stock'] ?>"
                 onclick="<?= $p['stock'] > 0 ? 'addToCart(' . $p['id'] . ', \'' . addslashes(e($p['name'])) . '\', \'' . e($p['sku']) . '\', ' . $p['price'] . ', ' . $p['discount'] . ', ' . $p['stock'] . ')' : '' ?>">
                <?php if ($p['discount'] > 0): ?>
                <div class="product-card-discount"><?= $p['discount'] ?>% OFF</div>
                <?php endif; ?>
                <div class="product-card-sku"><?= e($p['sku']) ?></div>
                <div class="product-card-name"><?= e($p['name']) ?></div>
                <div class="product-card-price"><?= formatRupiah($p['price'] * (1 - $p['discount']/100)) ?></div>
                <div class="product-card-stock <?= $p['stock'] <= 5 ? ($p['stock'] <= 0 ? 'stock-out' : 'stock-low') : '' ?>">
                    Stok: <?= $p['stock'] <= 0 ? 'Habis' : $p['stock'] ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Right: Cart -->
    <div class="pos-right">
        <div class="cart-header">
            <span>🛒 Keranjang</span>
            <span id="cartCount" class="badge badge-red">0</span>
        </div>
        <div class="cart-items" id="cartItems"></div>
        <div class="cart-empty" id="cartEmpty">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>
            <div>Keranjang masih kosong</div>
            <div style="font-size:12px;margin-top:4px">Klik produk atau input SKU</div>
        </div>
        <div class="cart-footer">
            <div class="cart-totals">
                <div class="cart-total-row"><span>Subtotal</span><span id="totalSubtotal">Rp 0</span></div>
                <div class="cart-total-row"><span>Diskon</span><span id="totalDiscount">- Rp 0</span></div>
                <div class="cart-total-row grand"><span>Total</span><span class="val" id="totalGrand">Rp 0</span></div>
            </div>
            <button class="btn btn-primary w-100 btn-lg" id="checkoutBtn" disabled onclick="openCheckout()">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
                Proses Pembayaran
            </button>
        </div>
    </div>
</div>

<!-- Payment Modal -->
<div class="modal-overlay" id="paymentModal">
    <div class="modal">
        <div class="modal-header">
            <span class="modal-title">Pembayaran</span>
            <button class="modal-close" onclick="closeModal('paymentModal')">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            </button>
        </div>
        <div class="modal-body">
            <div class="payment-row total">
                <span>Total Belanja</span>
                <span id="paymentGrand" class="text-red">Rp 0</span>
            </div>
            <div class="form-group mt-16">
                <label class="form-label">Uang Diterima</label>
                <input type="number" id="amountPaid" class="form-control" placeholder="0" oninput="calcChange()" style="font-size:18px;font-weight:700">
            </div>
            <!-- Quick amount buttons -->
            <div class="btn-group mb-16" id="quickAmounts"></div>
            <div class="payment-row change">
                <span>Kembalian</span>
                <span id="changeAmount">-</span>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('paymentModal')">Batal</button>
            <button class="btn btn-success" id="processPaymentBtn" disabled onclick="processPayment()">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>
                Bayar
            </button>
        </div>
    </div>
</div>

<form id="checkoutForm" method="POST" action="<?= BASE_URL ?>/index.php" style="display:none">
    <input type="hidden" name="cart" id="formCart">
    <input type="hidden" name="amount_paid" id="formAmountPaid">
</form>

<script>
var BASE_URL = '<?= BASE_URL ?>';
</script>
<?php $extraJs = 'pos.js'; ?>
</div>
<?php include 'includes/footer.php'; ?>
