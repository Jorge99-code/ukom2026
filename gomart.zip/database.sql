-- GoMart POS Database
CREATE DATABASE IF NOT EXISTS gomart_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE gomart_db;

-- Categories Table
CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    alias CHAR(3) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Cashiers Table
CREATE TABLE IF NOT EXISTS cashiers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin','cashier') DEFAULT 'cashier',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Products Table
CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    sku VARCHAR(50) NOT NULL UNIQUE,
    discount DECIMAL(5,2) DEFAULT 0,
    category_id INT NOT NULL,
    berat INT NOT NULL COMMENT 'gram',
    price DECIMAL(15,2) NOT NULL,
    stock INT DEFAULT 0,
    sold INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

-- Transactions Table
CREATE TABLE IF NOT EXISTS transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    kode VARCHAR(20) NOT NULL UNIQUE,
    cashier_id INT NOT NULL,
    grand_total DECIMAL(15,2) NOT NULL,
    amount_paid DECIMAL(15,2) NOT NULL,
    change_amount DECIMAL(15,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (cashier_id) REFERENCES cashiers(id)
) ENGINE=InnoDB;

-- Transaction Items Table
CREATE TABLE IF NOT EXISTS transaction_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    transaction_id INT NOT NULL,
    product_id INT NOT NULL,
    product_name VARCHAR(150) NOT NULL,
    product_sku VARCHAR(50) NOT NULL,
    qty INT NOT NULL,
    price DECIMAL(15,2) NOT NULL,
    discount DECIMAL(5,2) DEFAULT 0,
    subtotal DECIMAL(15,2) NOT NULL,
    FOREIGN KEY (transaction_id) REFERENCES transactions(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id)
) ENGINE=InnoDB;

-- Default Categories
INSERT INTO categories (nama, alias) VALUES
('Minuman', 'MNM'),
('Makanan', 'MKN'),
('Snack', 'SNK'),
('Kebersihan', 'KBR'),
('Rokok', 'ROK');

-- Default Admin (password: password)
INSERT INTO cashiers (username, email, password, role) VALUES
('admin', 'admin@gomart.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');

-- Sample Products
INSERT INTO products (name, sku, discount, category_id, berat, price, stock, sold) VALUES
('Aqua Botol', 'MNM-AQUABOTOL-600', 0, 1, 600, 4000, 100, 0),
('Indomie Goreng', 'MKN-INDOMIEGOREN-85', 0, 2, 85, 3500, 200, 0),
('Chitato Original', 'SNK-CHITATOORIG-68', 5, 3, 68, 12000, 50, 0),
('Sabun Lifebuoy', 'KBR-SABUNLIFEBU-80', 0, 4, 80, 6500, 75, 0),
('Gudang Garam Surya', 'ROK-GUDANGGARAMS-16', 0, 5, 16, 28000, 30, 0);
