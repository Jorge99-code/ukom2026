// GoMart POS - Cashier JS
var cart = [];

function addToCart(id, name, sku, price, discount, stock) {
    if (stock <= 0) return;
    var existing = cart.findIndex(function(i) { return i.id == id; });
    if (existing >= 0) {
        if (cart[existing].qty >= stock) {
            alert('Stok tidak cukup!');
            return;
        }
        cart[existing].qty++;
    } else {
        cart.push({ id: id, name: name, sku: sku, price: price, discount: discount, stock: stock, qty: 1 });
    }
    renderCart();
    updateProductCard(id, stock);
}

function addBySKU() {
    var skuInput = document.getElementById('skuInput');
    var sku = skuInput.value.trim().toUpperCase();
    if (!sku) return;

    var cards = document.querySelectorAll('.product-card[data-sku]');
    var found = false;
    cards.forEach(function(card) {
        if (card.getAttribute('data-sku') === sku) {
            var id = card.getAttribute('data-id');
            var name = card.getAttribute('data-name');
            var price = parseFloat(card.getAttribute('data-price'));
            var discount = parseFloat(card.getAttribute('data-discount'));
            var stock = parseInt(card.getAttribute('data-stock'));
            addToCart(id, name, sku, price, discount, stock);
            found = true;
        }
    });

    if (!found) {
        // Try AJAX lookup
        var xhr = new XMLHttpRequest();
        xhr.open('GET', BASE_URL + '/api/product_by_sku.php?sku=' + encodeURIComponent(sku), true);
        xhr.onload = function() {
            if (xhr.status === 200) {
                try {
                    var data = JSON.parse(xhr.responseText);
                    if (data.id) {
                        addToCart(data.id, data.name, data.sku, parseFloat(data.price), parseFloat(data.discount), parseInt(data.stock));
                    } else {
                        showSKUError('SKU tidak ditemukan');
                    }
                } catch(e) { showSKUError('SKU tidak ditemukan'); }
            }
        };
        xhr.send();
    }
    skuInput.value = '';
    skuInput.focus();
}

function showSKUError(msg) {
    var el = document.getElementById('skuError');
    if (el) {
        el.textContent = msg;
        el.style.display = 'block';
        setTimeout(function() { el.style.display = 'none'; }, 2000);
    }
}

function changeQty(id, delta) {
    var idx = cart.findIndex(function(i) { return i.id == id; });
    if (idx < 0) return;
    cart[idx].qty += delta;
    if (cart[idx].qty <= 0) {
        cart.splice(idx, 1);
    } else if (cart[idx].qty > cart[idx].stock) {
        cart[idx].qty = cart[idx].stock;
    }
    renderCart();
}

function removeFromCart(id) {
    cart = cart.filter(function(i) { return i.id != id; });
    renderCart();
}

function getItemSubtotal(item) {
    var discounted = item.price * (1 - item.discount / 100);
    return discounted * item.qty;
}

function renderCart() {
    var container = document.getElementById('cartItems');
    var emptyEl = document.getElementById('cartEmpty');
    var checkoutBtn = document.getElementById('checkoutBtn');

    if (cart.length === 0) {
        container.innerHTML = '';
        if (emptyEl) emptyEl.style.display = 'block';
        if (checkoutBtn) checkoutBtn.disabled = true;
        updateTotals(0, 0, 0);
        return;
    }
    if (emptyEl) emptyEl.style.display = 'none';
    if (checkoutBtn) checkoutBtn.disabled = false;

    var html = '';
    cart.forEach(function(item) {
        var sub = getItemSubtotal(item);
        var priceLabel = item.discount > 0
            ? '<s>' + formatRupiah(item.price) + '</s> (' + item.discount + '% off)'
            : formatRupiah(item.price);
        html += '<div class="cart-item">' +
            '<div class="cart-item-info">' +
            '<div class="cart-item-name">' + escapeHtml(item.name) + '</div>' +
            '<div class="cart-item-price">' + priceLabel + '</div>' +
            '</div>' +
            '<div class="cart-item-controls">' +
            '<button class="qty-btn" onclick="changeQty(' + item.id + ', -1)">−</button>' +
            '<span class="qty-display">' + item.qty + '</span>' +
            '<button class="qty-btn" onclick="changeQty(' + item.id + ', 1)">+</button>' +
            '</div>' +
            '<div class="cart-item-subtotal">' + formatRupiah(sub) + '</div>' +
            '<button class="cart-remove" onclick="removeFromCart(' + item.id + ')">' +
            '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>' +
            '</button>' +
            '</div>';
    });
    container.innerHTML = html;

    var subtotal = cart.reduce(function(s, i) { return s + i.price * i.qty; }, 0);
    var totalDisc = cart.reduce(function(s, i) { return s + (i.price * i.discount / 100) * i.qty; }, 0);
    var grand = subtotal - totalDisc;
    updateTotals(subtotal, totalDisc, grand);
}

function updateTotals(subtotal, disc, grand) {
    var els = {
        subtotal: document.getElementById('totalSubtotal'),
        discount: document.getElementById('totalDiscount'),
        grand: document.getElementById('totalGrand'),
        grandPayment: document.getElementById('paymentGrand')
    };
    if (els.subtotal) els.subtotal.textContent = formatRupiah(subtotal);
    if (els.discount) els.discount.textContent = '- ' + formatRupiah(disc);
    if (els.grand) els.grand.textContent = formatRupiah(grand);
    if (els.grandPayment) els.grandPayment.textContent = formatRupiah(grand);
    window._grandTotal = grand;
}

function openCheckout() {
    if (cart.length === 0) return;
    document.getElementById('amountPaid').value = '';
    document.getElementById('changeAmount').textContent = '-';
    document.getElementById('changeAmount').className = '';
    openModal('paymentModal');
    setTimeout(function() { document.getElementById('amountPaid').focus(); }, 100);
}

function calcChange() {
    var paid = parseFloat(document.getElementById('amountPaid').value) || 0;
    var grand = window._grandTotal || 0;
    var change = paid - grand;
    var el = document.getElementById('changeAmount');
    el.textContent = formatRupiah(Math.abs(change));
    el.className = change < 0 ? 'change-negative' : '';
    document.getElementById('processPaymentBtn').disabled = paid < grand;
}

function processPayment() {
    var paid = parseFloat(document.getElementById('amountPaid').value) || 0;
    var grand = window._grandTotal || 0;
    if (paid < grand) { alert('Uang tidak cukup!'); return; }

    var form = document.getElementById('checkoutForm');
    document.getElementById('formCart').value = JSON.stringify(cart);
    document.getElementById('formAmountPaid').value = paid;
    form.submit();
}

function updateProductCard(id, maxStock) {
    var card = document.querySelector('.product-card[data-id="' + id + '"]');
    if (!card) return;
    var inCart = cart.find(function(i) { return i.id == id; });
    var qtyInCart = inCart ? inCart.qty : 0;
    var remaining = maxStock - qtyInCart;
    var stockEl = card.querySelector('.product-card-stock');
    if (stockEl) stockEl.textContent = 'Stok: ' + remaining;
    if (remaining <= 0) card.classList.add('out-of-stock');
    else card.classList.remove('out-of-stock');
}

function filterProducts() {
    var q = document.getElementById('productSearch').value.toLowerCase();
    document.querySelectorAll('.product-card').forEach(function(card) {
        var name = (card.getAttribute('data-name') || '').toLowerCase();
        var sku = (card.getAttribute('data-sku') || '').toLowerCase();
        card.style.display = (name.includes(q) || sku.includes(q)) ? '' : 'none';
    });
}

function escapeHtml(str) {
    var d = document.createElement('div');
    d.textContent = str;
    return d.innerHTML;
}

// SKU input enter key
document.addEventListener('DOMContentLoaded', function() {
    var skuInput = document.getElementById('skuInput');
    if (skuInput) {
        skuInput.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') addBySKU();
        });
        skuInput.focus();
    }
    renderCart();
});
