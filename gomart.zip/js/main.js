// GoMart POS - Main JS

// Sidebar toggle (desktop)
document.addEventListener('DOMContentLoaded', function() {
    var sidebar = document.getElementById('sidebar');
    var mainContent = document.getElementById('mainContent');
    var toggleBtn = document.getElementById('sidebarToggle');

    if (toggleBtn && sidebar) {
        toggleBtn.addEventListener('click', function() {
            sidebar.classList.toggle('collapsed');
            if (mainContent) mainContent.classList.toggle('expanded');
        });
    }

    // Auto-hide alerts
    var alerts = document.querySelectorAll('.alert');
    alerts.forEach(function(alert) {
        setTimeout(function() {
            alert.style.opacity = '0';
            alert.style.transition = 'opacity 0.4s';
            setTimeout(function() { alert.remove(); }, 400);
        }, 4000);
    });

    // Modal close on overlay click
    document.querySelectorAll('.modal-overlay').forEach(function(overlay) {
        overlay.addEventListener('click', function(e) {
            if (e.target === overlay) closeModal(overlay.id);
        });
    });
});

// Mobile sidebar toggle
function toggleMobileSidebar() {
    var sidebar = document.getElementById('sidebar');
    var overlay = document.getElementById('sidebarOverlay');
    if (!sidebar) return;
    var isOpen = sidebar.classList.contains('mobile-open');
    if (isOpen) {
        sidebar.classList.remove('mobile-open');
        if (overlay) overlay.classList.remove('active');
        document.body.style.overflow = '';
    } else {
        sidebar.classList.add('mobile-open');
        if (overlay) overlay.classList.add('active');
        document.body.style.overflow = 'hidden';
    }
}

function openModal(id) {
    var el = document.getElementById(id);
    if (el) el.classList.add('active');
}
function closeModal(id) {
    var el = document.getElementById(id);
    if (el) el.classList.remove('active');
}

// Confirm delete
function confirmDelete(url, msg) {
    if (confirm(msg || 'Yakin mau hapus data ini?')) {
        window.location.href = url;
    }
}

// Format number to Rupiah display
function formatRupiah(num) {
    return 'Rp ' + num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
}

// Print receipt
function printReceipt() {
    var printContent = document.getElementById('receipt-content');
    if (!printContent) return;
    var w = window.open('', '_blank', 'width=400,height=600');
    w.document.write('<html><head><title>Struk GoMart</title>');
    w.document.write('<style>');
    w.document.write('body{font-family:monospace;font-size:12px;padding:10px;max-width:320px;margin:0 auto}');
    w.document.write('.receipt-header{text-align:center;margin-bottom:12px}');
    w.document.write('.receipt-divider{border:none;border-top:1px dashed #999;margin:8px 0}');
    w.document.write('.receipt-row{display:flex;justify-content:space-between;margin:3px 0}');
    w.document.write('.receipt-total-row{display:flex;justify-content:space-between;font-weight:bold}');
    w.document.write('h2{margin:0 0 4px;font-size:14px}h3{margin:0 0 2px;font-size:12px}p{margin:2px 0}');
    w.document.write('</style></head><body>');
    w.document.write(printContent.innerHTML);
    w.document.write('</body></html>');
    w.document.close();
    w.focus();
    setTimeout(function() { w.print(); }, 300);
}

function downloadReceiptPDF() {
    printReceipt();
}
