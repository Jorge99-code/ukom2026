<?php
// GoMart POS Config
define('STORE_NAME', 'GoMart');
define('STORE_LOCATION', 'Jatiwarna, Bekasi');

// Database
define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
define('DB_NAME', getenv('DB_NAME') ?: 'gomart_db');
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASS', getenv('DB_PASS') ?: '');

// Base URL
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'];
define('BASE_URL', $protocol . '://' . $host);

// Session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// DB Connection (mysqli)
function getDB() {
    static $conn = null;
    if ($conn === null) {
        $conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        if (!$conn) {
            die(json_encode(['error' => 'DB Connection failed: ' . mysqli_connect_error()]));
        }
        mysqli_set_charset($conn, 'utf8mb4');
    }
    return $conn;
}

// Auth helpers
function isLoggedIn() {
    return isset($_SESSION['cashier_id']);
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: ' . BASE_URL . '/pages/auth/login.php');
        exit;
    }
}

function requireAdmin() {
    requireLogin();
    if ($_SESSION['role'] !== 'admin') {
        header('Location: ' . BASE_URL . '/index.php?error=unauthorized');
        exit;
    }
}

function getCurrentCashier() {
    if (!isLoggedIn()) return null;
    return [
        'id' => $_SESSION['cashier_id'],
        'username' => $_SESSION['username'],
        'email' => $_SESSION['email'],
        'role' => $_SESSION['role'],
    ];
}

// Format Rupiah
function formatRupiah($amount) {
    return 'Rp ' . number_format($amount, 0, ',', '.');
}

// Generate Transaction Code
function generateTrxCode() {
    $db = getDB();
    $date = date('Ymd');
    $result = mysqli_query($db, "SELECT COUNT(*) as cnt FROM transactions WHERE DATE(created_at) = CURDATE()");
    $row = mysqli_fetch_assoc($result);
    $seq = str_pad($row['cnt'] + 1, 4, '0', STR_PAD_LEFT);
    return "TRX-{$date}-{$seq}";
}

// Escape
function e($str) {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}

function sanitize($str) {
    return mysqli_real_escape_string(getDB(), trim($str ?? ''));
}
